// Runs inside the Tessera frame, and only when that frame sits in the eXo page.
// Tessera shows its unread total in the page title, "(3) Tessera", so the count is read from there and handed to the
// drawer header. Nothing else about the conversations leaves the frame.
(() => {
  'use strict'
  const HOST = 'https://community.exoplatform.com'
  if (window === window.top) return
  // Chrome says who the frame's ancestors are; Firefox has no ancestorOrigins, so it falls back to the referrer, which the
  // drawer sets to the origin only (referrerpolicy="origin" on the iframe).
  const parentOrigin = location.ancestorOrigins?.[0] ?? (() => { try { return new URL(document.referrer).origin } catch { return undefined } })()
  if (parentOrigin !== HOST) return

  const read = () => {
    const m = /^\((\d{1,6})\)/.exec(document.title)
    return m ? Number(m[1]) : 0
  }
  let last = -1
  const send = () => {
    const count = read()
    if (count === last) return
    last = count
    window.parent.postMessage({ source: 'tessera-exo-extension', type: 'unread', count }, HOST)
  }
  // The colours of Tessera's current theme, so the drawer around it matches instead of staying dark in a light theme.
  const NAMES = ['bg', 'panel', 'tile', 'line', 'text', 'muted']
  let lastTheme = ''
  const sendTheme = () => {
    const cs = getComputedStyle(document.documentElement)
    const theme = Object.fromEntries(NAMES.map((n) => [n, cs.getPropertyValue(`--${n}`).trim()]))
    const key = JSON.stringify(theme)
    if (key === lastTheme || NAMES.some((n) => !theme[n])) return
    lastTheme = key
    window.parent.postMessage({ source: 'tessera-exo-extension', type: 'theme', theme }, HOST)
  }
  // Tell the drawer a fresh page has loaded (it uses this to know a reload worked).
  window.parent.postMessage({ source: 'tessera-exo-extension', type: 'hello' }, HOST)
  // A hard reload, asked for by the drawer's Reload button: forget the cached copy of Tessera (the offline shell and its
  // service worker), then load it again from the network. The session and messages live in IndexedDB and localStorage and
  // are not touched.
  addEventListener('message', async (e) => {
    if (e.origin !== HOST || e.source !== window.parent || e.data?.source !== 'tessera-exo-extension-host' || e.data.type !== 'hard-reload') return
    try {
      for (const r of await navigator.serviceWorker.getRegistrations()) await r.unregister()
    } catch {
      /* no service worker: nothing to forget */
    }
    try {
      for (const k of await caches.keys()) await caches.delete(k)
    } catch {
      /* no cache storage */
    }
    location.reload()
  })
  send()
  sendTheme()
  // The theme changes through data-theme on <html>, or with the system setting when it is on System.
  new MutationObserver(sendTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme', 'class', 'style'] })
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', sendTheme)
  // The title element can be replaced as well as edited, so watch the head.
  new MutationObserver(send).observe(document.head, { subtree: true, childList: true, characterData: true })
  addEventListener('pageshow', () => { send(); sendTheme() })
})()
