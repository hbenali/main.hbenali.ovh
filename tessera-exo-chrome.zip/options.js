const DEFAULT_URL = 'https://tessera.hbenali.ovh'
const input = document.getElementById('url')
const status = document.getElementById('status')
const preload = document.getElementById('preload')
chrome.storage.sync.get({ url: DEFAULT_URL, preload: true }, (r) => { input.value = r.url; preload.checked = r.preload !== false })
document.getElementById('save').addEventListener('click', () => {
  let url = input.value.trim() || DEFAULT_URL
  try {
    const x = new URL(url)
    const local = x.hostname === 'localhost' || x.hostname === '127.0.0.1'
    if (x.protocol !== 'https:' && !(x.protocol === 'http:' && local)) throw new Error('not https')
    url = x.href
  } catch {
    status.style.color = '#b3261e'
    status.textContent = 'Enter an https:// address.'
    return
  }
  chrome.storage.sync.set({ url, preload: preload.checked }, () => { status.style.color = '#0a6b49'; status.textContent = 'Saved.'; setTimeout(() => (status.textContent = ''), 1800) })
})
