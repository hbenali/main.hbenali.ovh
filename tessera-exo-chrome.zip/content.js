// Tessera for eXo Tribe.
// eXo's chat icon is replaced by a Tessera icon with an unread badge, and clicking it opens a drawer with Tessera in it
// instead of eXo's own chat drawer. The unread count comes from Tessera itself (see frame.js), so the drawer's page is
// loaded quietly in the background when an eXo page opens (the option "preload" turns that off).
(() => {
  'use strict'
  if (window.__tesseraDrawer) return // never install twice
  window.__tesseraDrawer = true

  const DEFAULT_URL = 'https://tessera.hbenali.ovh'
  const BUTTON_ID = 'btnChatButtonNew' // the chat icon in the top bar
  const WIDTH = 420

  // Where Tessera lives. Only https (or localhost while developing) is accepted, whatever was typed in the options.
  const safe = (u) => {
    try {
      const x = new URL(u)
      return x.protocol === 'https:' || (x.protocol === 'http:' && (x.hostname === 'localhost' || x.hostname === '127.0.0.1')) ? x.href : DEFAULT_URL
    } catch {
      return DEFAULT_URL
    }
  }
  // When the extension is reloaded or updated while an eXo tab stays open, that tab keeps running this (now orphaned)
  // script, and every call into the extension throws "Extension context invalidated". Storage is therefore only ever
  // touched through these helpers, which fall back to the defaults instead of throwing, so the drawer keeps working.
  const alive = () => {
    try {
      return !!globalThis.chrome?.runtime?.id
    } catch {
      return false
    }
  }
  const getStore = (area, defaults) =>
    new Promise((resolve) => {
      try {
        const a = alive() ? globalThis.chrome.storage?.[area] : undefined
        if (!a) return resolve(defaults)
        a.get(defaults, (r) => resolve(globalThis.chrome.runtime.lastError ? defaults : r))
      } catch {
        resolve(defaults)
      }
    })
  const setStore = (area, values) => {
    try {
      if (alive()) globalThis.chrome.storage?.[area]?.set(values)
    } catch {
      /* orphaned: nothing to save to */
    }
  }
  const loadOptions = async () => {
    const r = await getStore('sync', { url: DEFAULT_URL, preload: true })
    return { url: safe(r.url), preload: r.preload !== false }
  }
  const loadUrl = async () => (await loadOptions()).url

  // eXo's own chat button and drawers are never wanted: the button is replaced below, and the drawers are hidden in case
  // something else (a notification link) opens one.
  const hide = document.createElement('style')
  hide.textContent = '#matrixChatButton, #meedsChatDrawer, #ChatDiscussionDrawer, #meedsChatShareFileDrawer { display: none !important; }'
  document.head.append(hide)

  let unread = 0

  let host, root, frame, openerButton, tesseraOrigin
  let barHost, barRoot, barButton // the icon in eXo's top bar
  let open = false
  // Pinned: the drawer stays open (Esc does not close it) and comes back on every eXo page. Close or the chat icon unpins.
  let pinned = false
  const loadPinned = async () => (await getStore('local', { pinned: false })).pinned === true
  const savePinned = (v) => setStore('local', { pinned: v })
  function setPinned(v) {
    pinned = v
    savePinned(v)
    const b = root?.querySelector('.pin')
    if (b) {
      b.setAttribute('aria-pressed', String(v))
      b.title = v ? 'Unpin: Esc closes the drawer again' : 'Pin: keep the drawer open on every eXo page'
    }
  }

  // Static markup only (nothing from the page is interpolated), parsed into nodes instead of assigned with innerHTML.
  function markup(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html')
    const out = document.createDocumentFragment()
    out.append(...doc.head.childNodes, ...doc.body.childNodes) // a leading <style> is parsed into the head
    return out
  }

  function build(url) {
    host = document.createElement('div')
    host.id = 'tessera-drawer-host'
    root = host.attachShadow({ mode: 'closed' }) // isolated from the page's own styles
    root.append(markup(`
      <style>
        :host { all: initial; }
        /* Colours: dark by default, light with the system setting, then Tessera's own theme once the frame reports it. */
        .drawer { --bg: #0d0f14; --panel: #161922; --tile: #262b38; --line: #262b38; --text: #f3f4f8; --muted: #c9cdd8; }
        @media (prefers-color-scheme: light) { .drawer { --bg: #ffffff; --panel: #f5f6f8; --tile: #eceef2; --line: #e2e5ea; --text: #14171c; --muted: #596273; } }
        .drawer { position: fixed; top: var(--top, 0px); right: 0; height: calc(100vh - var(--top, 0px)); width: min(var(--w), 100vw); z-index: 2147483000; display: flex; flex-direction: column;
          background: var(--bg); color: var(--text); box-shadow: -8px 0 32px rgba(0,0,0,.35); transform: translateX(105%); visibility: hidden;
          transition: transform .2s ease, visibility 0s .2s; font: 14px system-ui, sans-serif; }
        .drawer.open { transform: none; visibility: visible; transition: transform .2s ease; }
        header { display: flex; align-items: center; gap: 6px; padding: 8px 10px 8px 14px; background: var(--panel); border-bottom: 1px solid var(--line); flex: none; }
        h2 { margin: 0; flex: 1; font-size: 14px; font-weight: 650; letter-spacing: -.01em; display: flex; align-items: center; gap: 8px; }
        .count { min-width: 20px; padding: 0 6px; border-radius: 999px; background: #e5484d; color: #fff; font-size: 11px; font-weight: 700; line-height: 20px; text-align: center; font-variant-numeric: tabular-nums; }
        .count[hidden] { display: none; }
        .stale { padding: 7px 14px; font-size: 12px; background: #fff3cd; color: #5c4400; border-bottom: 1px solid #ecd58a; } .stale[hidden] { display: none; }
        .sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
        button { all: unset; box-sizing: border-box; display: inline-grid; place-items: center; width: 32px; height: 32px; border-radius: 8px; cursor: pointer; color: var(--muted); }
        button:hover { background: var(--tile); color: var(--text); } .pin[aria-pressed=true] { color: var(--text); background: var(--tile); } .pin[aria-pressed=true] svg { fill: currentColor; } button:focus-visible { outline: 2px solid var(--text); outline-offset: 1px; }
        svg { width: 18px; height: 18px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
        iframe { flex: 1; width: 100%; border: 0; background: var(--bg); color-scheme: normal; }
        @media (prefers-reduced-motion: reduce) { .drawer, .drawer.open { transition: none; } }
      </style>
      <div class="drawer" role="dialog" aria-label="Tessera">
        <header>
          <h2>Tessera <span class="count" role="status" hidden><span class="num" aria-hidden="true"></span><span class="sr"></span></span></h2>
          <button class="reload" title="Reload Tessera (clears its cached copy, keeps your session)" aria-label="Reload Tessera"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/></svg></button>
          <button class="pin" aria-pressed="false" title="Pin: keep the drawer open on every eXo page" aria-label="Pin the drawer open"><svg viewBox="0 0 24 24"><path d="M12 17v5"/><path d="M9 3h6l-1 6 3 3v2H7v-2l3-3z"/></svg></button>
          <button class="expand" title="Open Tessera in a tab and close this drawer" aria-label="Open Tessera in a tab"><svg viewBox="0 0 24 24"><path d="M14 4h6v6"/><path d="M20 4l-8 8"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg></button>
          <button class="close" title="Close (Esc)" aria-label="Close Tessera"><svg viewBox="0 0 24 24"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>
        </header>
        <div class="stale" role="status" hidden>The extension was updated. Reload this page to use the new version.</div>
        <iframe title="Tessera" referrerpolicy="origin" allow="clipboard-read; clipboard-write; camera; microphone; fullscreen"></iframe>
      </div>`))
    root.querySelector('.drawer').style.setProperty('--w', `${WIDTH}px`)
    frame = root.querySelector('iframe')
    tesseraOrigin = new URL(url).origin
    frame.src = url // loaded once and then kept, so the app stays signed in and in sync while the drawer is closed
    root.querySelector('.reload').addEventListener('click', hardReload)
    root.querySelector('.pin').addEventListener('click', () => setPinned(!pinned))
    root.querySelector('.close').addEventListener('click', () => toggle(false))
    root.querySelector('.expand').addEventListener('click', () => {
      window.open(url, '_blank', 'noopener')
      toggle(false)
    })
    document.body.append(host)
  }

  async function toggle(force) {
    const next = force ?? !open
    if (next && !host) build(await loadUrl())
    open = next
    if (!open && pinned) setPinned(false) // closing on purpose (Close, or the chat icon) unpins
    // Start below the top bar, so the chat icon (and the counter eXo draws on it) stays visible and clickable.
    const below = openerButton?.isConnected ? Math.ceil(openerButton.getBoundingClientRect().bottom + 11) : 0
    host.style.setProperty('--top', `${innerWidth < 480 ? 0 : below}px`) // on a phone the drawer takes the whole screen
    root.querySelector('.drawer').classList.toggle('open', open)
    barButton?.setAttribute('aria-expanded', String(open))
    root.querySelector('.stale').hidden = alive()
    if (open) requestAnimationFrame(() => frame.focus())
    else if (openerButton?.isConnected) openerButton.focus()
  }

  // The number of unread messages, sent by frame.js from inside the Tessera frame. Only that frame, and only from
  // Tessera's own origin, is believed.
  // Hard reload: ask the frame's own script to clear Tessera's cached copy and reload. If nothing answers (another address
  // that frame.js does not run on), fall back to loading the address again.
  let helloAt = 0
  function hardReload() {
    const asked = Date.now()
    frame.contentWindow?.postMessage({ source: 'tessera-exo-extension-host', type: 'hard-reload' }, tesseraOrigin)
    setTimeout(() => { if (helloAt < asked) frame.src = frame.src }, 3000)
  }
  function showCount(n) {
    const grew = n > unread
    unread = n
    const text = n > 99 ? '99+' : String(n)
    if (root) {
      const box = root.querySelector('.count')
      box.hidden = n === 0
      root.querySelector('.num').textContent = text
      root.querySelector('.sr').textContent = `${n} unread`
      root.querySelector('header h2').title = n ? `${n} unread` : ''
    }
    if (barRoot) {
      const badge = barRoot.querySelector('.badge')
      badge.hidden = n === 0
      badge.textContent = text
      if (grew) { badge.classList.remove('pop'); void badge.offsetWidth; badge.classList.add('pop') } // a small pop when something new arrives
      barButton.setAttribute('aria-label', n ? `Tessera chat, ${n} unread` : 'Tessera chat')
      barButton.title = n ? `Tessera: ${n} unread` : 'Open Tessera'
    }
  }
  // A colour is only used if it is a plain hex or rgb() value, so nothing the frame sends can inject CSS.
  const COLOUR = /^(#[0-9a-f]{3,8}|rgba?\(\s*[\d.]+%?\s*[, ]\s*[\d.]+%?\s*[, ]\s*[\d.]+%?\s*([,/]\s*[\d.]+%?\s*)?\))$/i
  function applyTheme(theme) {
    const drawer = root.querySelector('.drawer')
    for (const name of ['bg', 'panel', 'tile', 'line', 'text', 'muted']) {
      if (typeof theme?.[name] === 'string' && COLOUR.test(theme[name].trim())) drawer.style.setProperty(`--${name}`, theme[name].trim())
    }
  }
  addEventListener('message', (e) => {
    if (!frame || e.source !== frame.contentWindow || e.origin !== tesseraOrigin) return
    const d = e.data
    if (d?.source === 'tessera-exo-extension' && d.type === 'hello') helloAt = Date.now()
    if (d?.source === 'tessera-exo-extension' && d.type === 'theme') applyTheme(d.theme)
    if (d?.source === 'tessera-exo-extension' && d.type === 'unread' && Number.isInteger(d.count) && d.count >= 0 && d.count < 1e6) showCount(d.count)
  })

  // ---- The icon in eXo's top bar ---------------------------------------------------------------------------------------
  // A solid speech bubble in the colour of the neighbouring icons, with eXo's round hover, a keyboard focus ring and a red unread
  // badge. It sits where eXo's own chat button was.
  // A solid speech bubble with three dots cut out, like eXo's own solid Font Awesome glyphs beside it.
  const BUBBLE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill-rule="evenodd" d="M12 2C6.48 2 2 5.95 2 10.8c0 2.4 1.1 4.6 2.9 6.2-.2 1.5-.8 2.9-1.6 3.9-.3.4 0 .9.5.9 2.1 0 4-.8 5.4-1.8.9.2 1.8.3 2.8.3 5.52 0 10-3.95 10-8.8S17.52 2 12 2zM8 9.7a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 0 0 0-2.6zm4 0a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 0 0 0-2.6zm4 0a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 0 0 0-2.6z"/></svg>'
  function mountBar() {
    const theirs = document.getElementById('chat')
    if (!theirs || barHost?.isConnected) return
    // Take the colour of eXo's own icon so the new one belongs in the bar, in a light or dark eXo theme.
    const colour = getComputedStyle(document.getElementById(BUTTON_ID) ?? theirs).color || '#5f6368'
    barHost = document.createElement('div')
    barHost.id = 'tessera-chat-button-host'
    barHost.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;flex:none'
    barRoot = barHost.attachShadow({ mode: 'closed' })
    barRoot.append(markup(`
      <style>
        :host { all: initial; }
        button { all: unset; box-sizing: border-box; position: relative; display: grid; place-items: center; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; color: var(--c, #5f6368); transition: background .15s, transform .1s; }
        /* eXo's buttons are round and tint themselves with their own colour on hover (8%) and focus (12%) */
        button:hover { background: color-mix(in srgb, currentColor 8%, transparent); } button:active { transform: scale(.94); }
        button:focus-visible { outline: 2px solid #4d74ff; outline-offset: 1px; }
        button[aria-expanded=true] { background: color-mix(in srgb, currentColor 12%, transparent); }
        /* eXo's own top-bar glyphs: 36px round buttons, 20px solid icons, grey #707070 */
        svg { width: 22px; height: 22px; fill: currentColor; stroke: none; }
        .badge { position: absolute; top: -2px; right: -3px; min-width: 18px; height: 18px; padding: 0 5px; border-radius: 9px; box-sizing: border-box; background: #e5484d; color: #fff;
          font: 700 11px/18px system-ui, sans-serif; text-align: center; font-variant-numeric: tabular-nums; box-shadow: 0 0 0 2px #fff; pointer-events: none; }
        .badge[hidden] { display: none; }
        .badge.pop { animation: pop .35s ease-out; } @keyframes pop { 0% { transform: scale(.4); } 60% { transform: scale(1.25); } 100% { transform: scale(1); } }
        @media (prefers-reduced-motion: reduce) { button, .badge.pop { transition: none; animation: none; } }
      </style>
      <button type="button" title="Open Tessera" aria-label="Tessera chat" aria-haspopup="dialog" aria-expanded="false">${BUBBLE}<span class="badge" hidden></span></button>`))
    barButton = barRoot.querySelector('button')
    barButton.style.setProperty('--c', colour)
    barButton.addEventListener('click', () => { openerButton = barButton; toggle() })
    theirs.before(barHost)
    openerButton = barButton
    if (unread) showCount(unread) // a count that arrived before the icon existed
    if (open) barButton.setAttribute('aria-expanded', 'true')
  }
  // eXo draws its top bar late and may redraw it, so look again whenever the page changes (once per frame at most).
  let queued = false
  new MutationObserver(() => {
    if (queued || barHost?.isConnected) return
    queued = true
    requestAnimationFrame(() => { queued = false; mountBar() })
  }).observe(document.documentElement, { childList: true, subtree: true })
  mountBar()

  // Taking over the click of eXo's own button, should it ever be shown: in the capture phase on the window, before eXo's own handler on the button sees it.
  addEventListener(
    'click',
    (e) => {
      const btn = e.composedPath().find((n) => n instanceof Element && n.id === BUTTON_ID)
      if (!btn) return
      e.preventDefault()
      e.stopImmediatePropagation()
      openerButton = btn
      toggle()
    },
    true,
  )
  // Unpinned, pressing anywhere else on the eXo page closes the drawer. The chat icon has its own toggle above, and a click
  // inside the drawer's header stays inside it (the frame's own clicks never reach this page).
  addEventListener(
    'pointerdown',
    (e) => {
      if (!open || pinned) return
      const path = e.composedPath()
      if (path.includes(host) || path.includes(barHost) || path.some((n) => n instanceof Element && n.id === BUTTON_ID)) return
      toggle(false)
    },
    true,
  )
  addEventListener(
    'keydown',
    (e) => {
      if (e.key === 'Escape' && open && !pinned) {
        e.stopPropagation()
        toggle(false)
      }
    },
    true,
  )

  // Pinned on a previous page: open again as soon as eXo has drawn its top bar (and with it our icon).
  loadPinned().then((was) => {
    if (!was) return
    const start = Date.now()
    const tick = async () => {
      if (barButton?.isConnected) {
        openerButton = barButton
        await toggle(true)
        setPinned(true)
      } else if (Date.now() - start < 20000) setTimeout(tick, 300)
    }
    tick()
  })

  // The unread count lives inside Tessera, so load it in the background (closed drawer) once the page has settled.
  loadOptions().then(({ url, preload }) => {
    if (!preload) return
    const go = () => { if (!host) build(url) }
    if ('requestIdleCallback' in window) requestIdleCallback(go, { timeout: 4000 })
    else setTimeout(go, 1500)
  })
})()
